#!/bin/bash
cd "$(dirname "$0")"
( sleep 1; open -a "Google Chrome" "http://localhost:8787/read-along.html" 2>/dev/null || open "http://localhost:8787/read-along.html" ) &
echo "Read Along is running. Leave this window open while she reads."
python3 -m http.server 8787 --bind 127.0.0.1
