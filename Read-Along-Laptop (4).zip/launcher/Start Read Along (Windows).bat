@echo off
title Read Along server - keep this window open while she reads
cd /d "%~dp0"
if not exist read-along.html (
  echo read-along.html is not in this folder. Put it next to this file and try again.
  pause
  exit /b
)
start "Read Along server" /min powershell -NoProfile -ExecutionPolicy Bypass -Command "$l=New-Object System.Net.HttpListener; $l.Prefixes.Add('http://localhost:8787/'); $l.Start(); while($true){ $c=$l.GetContext(); $rel=$c.Request.Url.LocalPath.TrimStart('/'); if($rel -eq ''){ $rel='read-along.html' }; $p=Join-Path '%~dp0' $rel; if(Test-Path $p){ $b=[IO.File]::ReadAllBytes($p); $c.Response.ContentType='text/html; charset=utf-8'; $c.Response.ContentLength64=$b.Length; $c.Response.OutputStream.Write($b,0,$b.Length) } else { $c.Response.StatusCode=404 }; $c.Response.Close() }"
timeout /t 2 >nul
set URL=http://localhost:8787/read-along.html
set CHROME=
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe
if defined CHROME (
  start "" "%CHROME%" "%URL%"
) else if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
  start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" "%URL%"
) else (
  start "" "%URL%"
)
echo.
echo Read Along is open in your browser at http://localhost:8787/read-along.html
echo If it opened in the wrong browser, paste that address into Chrome or Edge.
echo.
echo You can close THIS window. Leave the small "Read Along server" window open while she reads.
pause
